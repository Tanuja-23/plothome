<?php
session_start();
$connection=mysqli_connect("localhost","root","","database1");
$_SESSION['user_login']=0;
$password="";
$error="";
if(isset($_POST['submit']))
{
	$emailid=$_POST['email'];
	$username=$_POST['username'];
	
	$query="select * from logindb where username='".$username."' and email_ID='".$emailid."'";
	$result=mysqli_query($connection,$query);
	$count=mysqli_num_rows($result);
        mysqli_query($connection,$query);
        if($count==1)
        {
        $row=mysqli_fetch_assoc($result);
        $password=$row['password'];
        }
        else
        {
            $error="Invalid Email or Password.";
        }
        
    }
?>
<!Doctype html>
<html>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        form {
            background-color:rgba(255, 255, 255, 0.819);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        form h2 {
            margin-top: 0;
            font-size: 24px;
            color: #040404;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #070707;
        }

        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            border: none;
            border-radius: 4px;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }
        .error { color: red;
            font-size:15px;
        }
    </style>
</head>
<body>
<!-- <body background="bg9.jpg" style="background-repeat: no-repeat; background-size: 1400px; background-position-x: 0px; background-position-y: 0px;"> -->
    <form method="POST">
        <h2>Show Password</h2>
       
        <label for="email">Enter Email ID</label>
        <input type="email" id="email" name="email" required>
        
        <label for="text">Enter Username</label>
        <input type="text" id="username" name="username" required>
        <br><br>
        <label for="text">Your Password is</label>
        <input type="text" id="password" name="password" value=<?php echo $password; ?>>
        <br><br>
        <span class="error"><?php echo $error; ?></span>
        <input type="submit" name="submit" value="Show Password">
    </form>

</body>
</html>