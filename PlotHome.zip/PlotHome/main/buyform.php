<?php
$connection=mysqli_connect("localhost","root","","database1");
?>
<!-- <!DOCTYPE html> -->
<html>
<head>
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
  <style>
/* Reset default styles and set up body */
body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
}

/* Container styles */
.container {
    max-width: 800px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Heading styles */
h2 {
    text-align: center;
}

/* Form group styles */
.form-group {
    margin-bottom: 20px;
}

/* Label styles */
label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
}

/* Input styles */
input[type="text"],
input[type="email"],
input[type="tel"],
textarea,
select {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box; /* Ensure padding doesn't increase width */
}

textarea {
    resize: vertical; /* Allow vertical resizing of textarea */
}

/* Checkbox styles */
input[type="checkbox"] {
    display: inline-block;
    margin-right: 10px;
}

/* Button styles */
button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background-color: #45a049;
}

button:focus {
    outline: none;
}

/* Adjustments for smaller screens */
@media (max-width: 600px) {
    .container {
        margin: 10px;
        padding: 15px;
    }

    button {
        width: 100%; /* Full width buttons on smaller screens */
    }
}

    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Buy Form</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <div class="container-fluid nav-bar bg-transparent">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4">
                    <div class="icon p-2 me-2">
                        <img class="img-fluid" src="bg7.png" alt="Icon" style="width: 90px; height: 70px;">
                    </div>
                    <h1 class="m-0 text-primary"><span style="color:black">Plot</span>Home</h1>
                
        </div>
        <form method="POST">
            <br>
            <h2>Property Buy Form</h2>

            <div class="form-group">
                <label for="fullname">Full Name</label>
                <input type="text" id="fullname" name="fullname" >
            </div>

            <div class="form-group">
                <label for="fullname">Property Name</label>
                <input type="text" id="proname" name="proname" >
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" >
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone" pattern="[0-9]{10}" >
                <small>Format: 1234567890</small>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <textarea id="address" name="address" rows="4" ></textarea>
            </div>

            <div class="form-group">
                <label for="property-type">Property Type</label>
                <select id="property-type" name="property-type" >
                    <option value="">Select Property Type</option>
                    <option value="house">House</option>
                    <option value="apartment">Apartment</option>
                    <option value="condo">Villa</option>
                    <option value="plot">Plot</option>
                </select>
            </div>

            <div class="form-group">
                <input type="checkbox" id="decision" name="decision" >Can you make an immediate decision if you find the right property?
                <span class="checkmark"></span>
            </div>

            <div class="form-group">
                <input type="submit" value="submit" name="submit" style=" background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;">
                <button type="button" onclick="window.location.href='index.php';">Back</button>
            </div>
        </form>
    </div>
    <?php

if(isset($_POST['submit']))
{
	
	$buyername=$_POST['fullname'];
	$propertyname=$_POST['proname'];
	$email=$_POST['email'];
	$phonenumber=$_POST['phone'];
	$address=$_POST['address'];
    $query1="SELECT * FROM `property_details` WHERE property_name='".$propertyname."'";
    $result=mysqli_query($connection, $query1);
    $id='';
while($row=mysqli_fetch_assoc($result))
{
    $id=$row['id'];
}
    $property_id=$_POST['proname']."_".$id;
	$query="insert into booking_details (buyer_name,property_name,email,Mobile_no,Address,property_id) values 
    ('".$buyername."','".$propertyname."','".$email."','".$phonenumber."','".$address."','".$property_id."')";
	mysqli_query($connection, $query);
    ?>
    <script>
        window.location.href="formpayment.php";
        </script>
    <?php
}
?>
</body>
</html>