<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
       
/* Body styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 190vh;
    margin: 0;
}

/* Container styles */
.container {
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 800px;
    max-width: 90%;
}

/* Form group styles */
.form-group {
    margin-bottom: 20px;
}

/* Label styles */
label {
    display: block;
    margin-bottom: 5px;
}

/* Input styles */
input[type="text"],
input[type="email"],
input[type="number"],
input[type="date"] {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box; /* Ensure padding doesn't increase width */
}

/* Button styles */
button {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 12px 24px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    cursor: pointer;
    border-radius: 4px;
    transition: background-color 0.3s;
    margin-top: 10px;
}

button:hover {
    background-color: #45a049;
}

/* Heading styles */
h1 {
    text-align: center;
    margin-bottom: 20px;
}

    </style>
</head>
<body>

<div class="container">
    <div class="container-fluid nav-bar bg-transparent">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4">
            <a href="index.html" class="navbar-brand d-flex align-items-center text-center">
                <div class="icon p-2 me-2">
                    <img class="img-fluid" src="bg7.png" alt="Icon" style="width: 90px; height: 70px;">
                </div>
                <h1 class="m-0 text-primary"><span style="color:black">Plot</span>Home</h1>
            </a>
            
    </div>
    <form method="post" id="paymentForm">
        <br>
        <h1>Personal Information</h1>
        <div class="form-group">
            <label for="firstName">First Name</label>
            <input type="text" id="firstName" name="firstName" placeholder="Enter your first name" required>
        </div>
        <div class="form-group">
            <label for="lastName">Last Name</label>
            <input type="text" id="lastName" name="lastName" placeholder="Enter your last name" required>
        </div>
        <div class="form-group">
            <label for="dob">Date of Birth</label>
            <input type="date" id="dob" name="dob" required>
        </div>

        <h1>Contact Information</h1>
        <div class="form-group">
            <label for="phoneNumber">Phone Number</label>
            <input type="number" id="phoneNumber" name="phoneNumber" placeholder="Enter your phone number" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>
        </div>
        <div class="form-group">
            <label for="city">City</label>
            <input type="text" id="city" name="city" placeholder="Enter your city" required>
        </div>

        <h1>Payment Information</h1>
        <div class="form-group">
            <label for="bankName">Bank Name</label>
            <input type="text" id="bankName" name="bankName" placeholder="Enter bank name" required>
        </div>
        <div class="form-group">
            <label for="branchName">Branch Name</label>
            <input type="text" id="branchName" name="branchName" placeholder="Enter branch name" required>
        </div>
        <div class="form-group">
            <label for="accountNumber">Account Number</label>
            <input type="number" id="accountNumber" name="accountNumber" placeholder="Enter account number" required>
        </div>

        <div class="form-group">
            <button type="submit">Submit Payment</button>
            <a href="buyform.php"><button type="button">Back</button></a>
        </div>
    </form>
</div>

</body>
</html>
