<?php

$connection=mysqli_connect("localhost","root","","database1");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property details</title>
    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 350vh;
            margin: 0;
        }

        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            width: 800px;
            max-width: 90%;
            overflow: hidden;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
        }

        input[type="text"], input[type="number"], input[type="email"], textarea, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
        }

        textarea {
            min-height: 100px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 24px;
            text-align: center;
            text-decoration: none;
            display: block;
            width: 100%;
            font-size: 18px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }

        h1, h3 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        a {
            text-decoration: none;
            color: #4CAF50;
        }

        .form-title {
            border-bottom: 2px solid #ccc;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }

        .form-title h1 {
            font-size: 24px;
        }

        .form-title h3 {
            font-size: 18px;
        }

        .form-title:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }

        .form-title-align-right {
            text-align: right;
        }

        .form-title-align-center {
            text-align: center;
        }
    </style>
</head>
<body>
    

<div class="container">
<div class="container-fluid nav-bar bg-transparent">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4">
                <a href="index.html" class="navbar-brand d-flex align-items-center text-center">
                    <div class="icon p-2 me-2">
                        <img class="img-fluid" src="bg7.png" alt="Icon" style="width: 90px; height: 70px;">
                    </div>
                    <h1 class="m-0 text-primary"><span style="color:black">Plot</span>Home</h1>
                </a>
                
        </div>
    <form  method="POST" enctype="multipart/form-data">
        <div class="form-title">
            <br>
            <h1>Property Details</h1>
        </div>

        <div class="form-group">
            <label for="selectp">Select Property Type</label>
            <select name="selectp" id="selectp">
                <option disabled selected>Select Property Type</option>
                <option>Apartment</option>
                <option>Home</option>
                <option>Villa</option>
                <option>Plot</option>
            </select>
        </div>

        <div class="form-group">
            <label for="PropertyName">Enter Property Name</label>
            <input type="text" id="PropertyName" name="PropertyName" placeholder="Property Name" >
        </div>

        <div class="form-group">
            <label for="Price">Enter Price</label>
            <input type="text" id="Price" name="Price" placeholder="Price" >
        </div>

        <div class="form-group">
            <label for="description">Enter Description</label>
            <textarea name="description" id="description" placeholder="Description"></textarea>
        </div>

        <div class="form-group">
            <label for="address">Enter Address</label>
            <textarea name="address" id="address" placeholder="Address"></textarea>
        </div>

        <div class="form-group">
            <label for="plotarea">Enter Plot Area</label>
            <input type="text" name="plotarea" id="plotarea" placeholder="Plot Area">
        </div>

        <div class="form-group">
            <label for="Pimg1">Upload Property Image</label>
            <input type="file" id="Pimg1" name="Pimg1" >
        </div>

        <div class="form-title">
            <h1>Owner Details</h1>
        </div>

        <div class="form-group">
            <label for="oname">Enter Owner Name</label>
            <input type="text" name="oname" id="oname" placeholder="Owner Name">
        </div>

        <div class="form-group">
            <label for="ownerno">Enter Owner Contact No</label>
            <input type="text" name="ownerno" id="ownerno" placeholder="Owner Contact No">
        </div>

        <div class="form-group">
            <label for="owneremail">Enter Owner Email</label>
            <input type="email" name="owneremail" id="owneremail" placeholder="Owner Email">
        </div>

        <div class="form-group">
            <label for="owneradd">Enter Owner Address</label>
            <textarea name="owneradd" id="owneradd" placeholder="Owner Address"></textarea>
        </div>

        <div class="form-title">
            <h1>Agent's Details</h1>
        </div>

        <div class="form-group">
            <label for="agentphoto">Upload Agent Photo</label>
            <input type="file" id="agentphoto" name="agentphoto" >
        </div>

        <div class="form-group">
            <label for="agentname">Enter Agent Name</label>
            <input type="text" id="agentname" name="agentname" placeholder="Agent Name">
        </div>

        <div class="form-group">
            <label for="Aaddress">Enter Agent's Address</label>
            <textarea name="Aaddress" id="Aaddress" placeholder="Agent's Address"></textarea>
        </div>

        <div class="form-group">
            <label for="Aemail">Enter Agent's Email</label>
            <input type="email" id="Aemail" name="Aemail" placeholder="Agent's Email">
        </div>

        <div class="form-group">
            <label for="cnum">Enter Agent's Contact Number</label>
            <input type="text" id="cnum" name="cnum" placeholder="Agent's Contact Number">
        </div>

        <input type="submit" name="submit" value="Add Property" style="background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 24px;
            text-align: center;
            text-decoration: none;
            display: block;
            width: 100%;
            font-size: 18px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s;">

    </form>
<br><br>
    <div class="form-title form-title-align-right">
        <a href="index.php">Back</a>
    </div>
</div>
<?php
if(isset($_POST['submit']))
{
	$propertytype=$_POST['selectp'];
	$propertyname=$_POST['PropertyName'];
	$price=$_POST['Price'];
	$description=$_POST['description'];
	$address=$_POST['address'];
	$plotarea=$_POST['plotarea'];
	$ownername=$_POST['oname'];
	$ownercontact=$_POST['ownerno'];
	$owneremail=$_POST['owneremail'];
	$owneraddress=$_POST['owneradd'];
	$agentname=$_POST['agentname'];
	$agentaddress=$_POST['Aaddress'];
	$agentemail=$_POST['Aemail'];
	$agentcontact=$_POST['cnum'];

    $file_name=$_FILES['Pimg1']['name'];
    $tempname=$_FILES['image']['tmp_name'];
    $folder='main/img/'.$file_name;
    // $query=mysqli_query($connection,"Insert into property_details(property_image) values ('$file_name')");
   
    $gid=mysqli_query($connection,"select (id) from property_details where name='$propertyname'");
    $file_name1=$_FILES['agentphoto']['name'];
    $tempname1=$_FILES['image']['tmp_name'];
    $folder1='main/img/'.$file_name1;
    // $query=mysqli_query($connection,"Insert into property_details(agent_photo) values ('$file_name1')");
	
    $query="insert into property_details (property_type,property_name,price,description,property_address,plot_area,property_image,owner_name,owner_contact,owner_email,owner_address,agent_photo,agent_name,agent_address,agent_email,agent_contact) values 
    ('".$propertytype."','".$propertyname."','".$price."','".$description."','".$address."','".$plotarea."','$file_name','".$ownername."','".$ownercontact."','".$owneremail."','".$owneraddress."','$file_name1','".$agentname."','".$agentaddress."','".$agentemail."','".$agentcontact."')";
    mysqli_query($connection, $query);
    
    
    
    ?>
    <script>
        window.location.href="index.php";
        </script>
    <?php
}
?>
</body>
</html>