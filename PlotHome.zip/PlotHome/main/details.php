<?php

$connection=mysqli_connect("localhost","root","","database1");

?>
<!DOCTYPE html>
<html lang="en">
<head>
<link href="img/favicon.ico" rel="icon">

<!-- Google Web Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">

<!-- Icon Font Stylesheet -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link href="lib/animate/animate.min.css" rel="stylesheet">
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

<!-- Customized Bootstrap Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Template Stylesheet -->
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Listing</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Inline styles for demonstration purposes only */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            position: relative; /* Ensure relative positioning for icon placement */
        }

        h1, h2, h3 {
            text-align: center;
        }

        img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .property-info {
            margin-bottom: 20px;
        }

        .agents {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
        }

        .agent-details {
            margin-left: 20px;
        }

        table {
            width: 100%;
            margin-top: 20px;
        }

        table img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }

        table td {
            vertical-align: top;
            padding: 10px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }

        button:hover {
            background-color: #45a049;
        }

        button:focus {
            outline: none;
        }

        /* Company icon styles */
        .company-icon {
            position: absolute;
            top: 20px;
            left: 20px;
            width: 50px;
            height: auto;
            border-radius: 50%;
            background-color: #4CAF50;
            padding: 5px;
        }

        .company-icon img {
            display: block;
            width: 100%;
            height: auto;
            border-radius: 50%;
        }
    </style>
</head>
<body >

<?php
                 
                 $gid=$_GET['id'];
                 $query="select * from property_details where id='".$gid."'";
                 $result=mysqli_query($connection, $query);
                 
                 while($row=mysqli_fetch_assoc($result))
                  {
                      ?>
                   
                    <div class="container">
    <!-- Company Icon -->
    <div class="container-fluid nav-bar bg-transparent">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4">
            <a href="index.html" class="navbar-brand d-flex align-items-center text-center">
                <div class="icon p-2 me-2">
                    <img class="img-fluid" src="bg7.png" alt="Icon" style="width: 90px; height: 70px;">
                </div>
                <h1 class="m-0 text-primary"><span style="color:black">Plot</span>Home</h1>
            </a>
            
    </div>
<br>
    <h2><?php echo $row['property_name']; ?></h2>
    <h1 align="center">
        <img src="img/<?php echo $row['property_image'] ?>" width="500" height="500">
    </h1>
    <div class="property-info">
        <h5 style="color:black; margin-left:80px;"><span style="color: rgb(5, 5, 46); font-size:25px;">Price:</span> <?php echo $row['price']; ?><br>
        <span style="color: rgb(5, 5, 46);font-size:25px;">Plot Area: </span> <?php echo $row['plot_area']; ?><br>
        <span style="color: rgb(5, 5, 46);font-size:25px;">Description:</span> <?php echo $row['description']; ?><br>
        <span style="color: rgb(5, 5, 46);font-size:25px;">Address:</span><?php echo $row['property_address']; ?><br><br></h5 style="color:black">
        <a href="buyform.php">
          <h1 align="center">  <button class="login-button">Buy</button></h1>
        </a>
    </div>
    <hr>

    <h2>Location</h2>
    <div>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.1422937950147!2d-73.98731968482413!3d40.75889497932681!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25855c6480299%3A0x55194ec5a1ae072e!2sTimes+Square!5e0!3m2!1ses-419!2sve!4v1510329142834" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    </div>
<hr>
    <h2>Agents</h2>
    <div class="agents">
        <img src="img/<?php echo $row['agent_photo'] ?>" height="300px" width="200px" >
        <div class="agent-details">
            <h3 align="center"><?php echo $row['agent_name']; ?></h3>
           <h5 style="color:black; margin-left:80px;"><span style="color: rgb(5, 5, 46); font-size:25px;"> Email:</span> <?php echo $row['agent_email']; ?><br>
            <span style="color: rgb(5, 5, 46); font-size:25px;"> Contact:</span> <?php echo $row['agent_contact']; ?> <br>
            <span style="color: rgb(5, 5, 46); font-size:25px;"> Address:</span> <?php echo $row['agent_address']; ?><br></h5>
        </div>
    </div>
<hr>

    <h2>Owner Information</h2>
    <div class="agents">
        <div class="agent-details">

        <h5 style="color:black; margin-left:80px;"><span style="color: rgb(5, 5, 46); font-size:25px;">Owner Name:</span> <?php echo $row['owner_name']; ?><br>
            <span style="color: rgb(5, 5, 46); font-size:25px;">Email:</span> <?php echo $row['owner_email']; ?><br>
            <span style="color: rgb(5, 5, 46); font-size:25px;">Contact:</span> <?php echo $row['owner_contact']; ?><br>
            <span style="color: rgb(5, 5, 46); font-size:25px;">Address:</span> <?php echo $row['owner_address']; ?><br>
        </div>
    </div>

    <div align="right">
        <a href="index.php">
            <button class="login-button">Back</button>
        </a>
    </div>
</div>
                 
                 <?php
                 }
                 ?> 



</body>
</html>