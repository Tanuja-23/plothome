<?php

$connection=mysqli_connect("localhost","root","","database1");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Basic CSS reset for cross-browser consistency */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        /* Center the button horizontally and vertically */
        body {
            
            justify-content: center;
            align-items: center;
         
            background-color: #f0f0f0; /* Background color for the body */
        }
        
        /* Styling for the login button */
        .login-button {
            background-color: #4CAF50; /* Green background */
            border: none; /* Remove border */
            color: white; /* White text color */
            padding: 8px 25px; /* Padding inside the button */
            text-align: center; /* Center text horizontally */
            text-decoration: none; /* Remove underline */
            display: inline-block; /* Display as inline-block */
            font-size: 16px; /* Font size */
            margin: 4px 2px; /* Margin around the button */
            cursor: pointer; /* Add cursor pointer */
            border-radius: 8px; /* Rounded corners */
            transition: background-color 0.3s ease; /* Smooth background color transition */
        }
        
        /* Change button background color on hover */
        .login-button:hover {
            background-color: #45a049; /* Darker green */
        }
        
            </style>
    <meta charset="utf-8">
    <title>Plots</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid nav-bar bg-transparent">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4">
            <a href="index.html" class="navbar-brand d-flex align-items-center text-center">
                <div class="icon p-2 me-2">
                    <img class="img-fluid" src="bg7.png" alt="Icon" style="width: 90px; height: 70px;">
                </div>
                <h1 class="m-0 text-primary"><span style="color:black">Plot</span>Home</h1>
            </a>
            
    </div>
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-0 gx-5 align-items-end">
                    <div class="col-lg-6">
                        <div class="text-start mx-auto mb-5 wow slideInLeft" data-wow-delay="0.1s">
                            <h1 class="mb-3">Plots</h1>
                          
                        </div>
                    </div>
                   
                </div>
                <?php
$query = "SELECT * FROM `property_details` WHERE property_type='Plot'";
$result = mysqli_query($connection, $query);
$count = 0; // Initialize a counter to keep track of columns

while ($row = mysqli_fetch_assoc($result)) {
    // Start a new row after every 3 items
    if ($count % 3 == 0) {
        echo '<div class="tab-content">
                <div id="tab-1" class="tab-pane fade show p-0 active">
                    <div class="row g-4">';
    }
    ?>

    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
        <div class="property-item rounded overflow-hidden">
            <div class="position-relative overflow-hidden">
                <a href="details.php?id=<?php echo $row['id']; ?>"><img class="img-fluid" src="img/<?php echo $row['property_image'] ?>" alt=""></a>
            </div>
            <div class="p-4 pb-0">
                <h5 class="text-primary mb-3"><?php echo $row['price']; ?></h5>
                <a class="d-block h5 mb-2" href=""><?php echo $row['property_name']; ?></a>
                <p><i class="fa fa-map-marker-alt text-primary me-2"></i><?php echo $row['property_address']; ?></p>
            </div>
            <div class="d-flex border-top">
                <small class="flex-fill text-center border-end py-2"><i class="fa fa-ruler-combined text-primary me-2"></i><?php echo $row['plot_area']; ?></small>
                <!-- Add more fields here as needed -->
            </div>
        </div>
    </div>

    <?php
    // End the row after every 3 items
    $count++;
    if ($count % 3 == 0) {
        echo '</div></div></div>'; // Close row, tab-pane, and tab-content
        ?>
        <br><br>
                <?php
    }
}

// Close any open row and tab-pane if the total items are not a multiple of 3
if ($count % 3 != 0) {
    echo '</div></div></div>'; // Close row, tab-pane, and tab-content
}
?>

                            
                                     <a href="index.php">
                                        <h1 align="right">      <button class="login-button">Back</button></h1>                                        </a>                                                       
    
</body>

</html>
