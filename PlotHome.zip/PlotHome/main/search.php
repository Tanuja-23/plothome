<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="search-container">
        <h2>Search Results</h2>
        <?php
        // Check if the form was submitted
        if ($_SERVER["REQUEST_METHOD"] == "GET") {
            // Retrieve search query and category
            $query = isset($_GET['query']) ? $_GET['query'] : '';
            $category = isset($_GET['category']) ? $_GET['category'] : 'all';

            // Perform search based on category
            switch ($category) {
                case 'Apartment':
                    // Perform search in books database or array
Header("Location:Apartments.php") ;                
   break;
                case 'Home':
                 
                    Header("Location:home.php") ;                
                    break;
                case 'Villa':
                
                    Header("Location:villa.php") ;                
                    break;
                case 'Plot':
                
                    Header("Location:plot.php") ;                
                    break;
                    
                    
                default:
                   
echo "No results found";
                    break;
            }
        }
        ?>
        <p><a href="index.php">Back to Search</a></p>
    </div>
</body>
</html>
