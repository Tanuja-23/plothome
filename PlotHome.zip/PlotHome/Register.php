 <?php

include "config.php";

$username = $password = "";
$username_err = $password_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter a username.";
    } else {
        $username = trim($_POST["username"]);
        if (!preg_match("/^[a-zA-Z]+$/", $username)) {
            $username_err = "Username can only contain letters.";
        }
    }
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";     
    } elseif (strlen(trim($_POST["password"])) < 8) {
        $password_err = "Password must be at least 8 characters.";
    } else {
        $password = trim($_POST["password"]);
    }
    
    if (empty($username_err) && empty($password_err)) {
        echo "Registration successful!";
        $emailid=$_POST['email'];
        $username=$_POST['username'];
        $password=$_POST['password'];
        
        $query="insert into logindb (username,password,email_ID) values ('".$username."','".$password."','".$emailid."')";
        mysqli_query($connection,$query);       
          header("location: main\index.php");
    }
}
?>

<html>
    <head>
<style>
    
        .error { color: red;
        font-size:15px;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        form {
            background-color:rgba(255, 255, 255, 0.819);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        form h2 {
            margin-top: 0;
            font-size: 24px;
            color: #040404;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #070707;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            border: none;
            border-radius: 4px;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }
    </style>
</head>
<body background="bg9.jpg" style="background-repeat: no-repeat; background-size: 1400px; background-position-x: 0px; background-position-y: 0px;">

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <h2>Register</h2>
        <label for="fname">Enter Email ID</label>
        <input type="email" id="email" name="email" required>
        
        <label for="username">Enter Username</label>
        <input type="text" id="username" name="username" required>
        <span class="error"><?php echo $username_err; ?></span>
        
        <label for="password">Enter Password</label>
        <input type="password" id="password" name="password" required>
        <span class="error"><?php echo $password_err; ?></span>
        
        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>





