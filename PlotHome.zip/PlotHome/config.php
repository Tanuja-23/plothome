<?php

$connection=mysqli_connect("localhost","root","","database1");
?>