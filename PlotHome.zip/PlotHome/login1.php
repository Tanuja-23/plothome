
<?php
include "config.php";
session_start();
?>
<html>
    <head>
<style>

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #fff;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #8f8f8f;
            border: none;
            border-radius: 4px;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap');
        * 
        {
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Poppins',sans-serif;
        } 
        body
        {
            display: flex;
            justify-content: center;
            align-items:center;
            min-height:100vh;
            background:#23242a;
        }
        .box 
        {
            position: relative;
            width: 380px;
            height:420px;
            background:#1c1c1c;
            border-radius:8px;
             overflow: hidden;
        }
        .box::before
        {
            content:'';
            position: absolute;
            top:-50%;
            left:-50%;
            width: 380px;
            height:420px;
            background:linear-gradient(0deg,transparent,transparent,#45f3ff,#45f3ff,#45f3ff);
            z-index:1;
            transform-origin: bottom right;
            animation: animate 6s linear infinite;
        }
        .box::after
        {
            content:'';
            position: absolute;
            top:-50%;
            left:-50%;
            width: 380px;
            height:420px;
            background:linear-gradient(0deg,transparent,transparent,#45f3ff,#45f3ff,#45f3ff);
            z-index:1;
            transform-origin: bottom right;
            animation: animate 6s linear infinite;
            animation-delay:-3s;
        }
        .borderline
        {
            position: absolute;
            top:0;
            inset:0;

        }
        .borderline::before
        {
            content:'';
            position: absolute;
            top:-50%;
            left:-50%;
            width: 380px;
            height:420px;
            background:linear-gradient(0deg,transparent,transparent,#ff2770,#ff2770,#ff2770);
            z-index:1;
            transform-origin: bottom right;
            animation: animate 6s linear infinite; 
            animation-delay:-1.5s;
        }
        .borderline::after
        {
            content:'';
            position: absolute;
            top:-50%;
            left:-50%;
            width: 380px;
            height:420px;
            background:linear-gradient(0deg,transparent,transparent,#ff2770,#ff2770,#ff2770);
            z-index:1;
            transform-origin: bottom right;
            animation: animate 6s linear infinite; 
            animation-delay:-4.5s;
        }
        @keyframes animate
        {
            0% 
            {
                transform: rotate(0deg);
            }
            100% 
            {
                transform: rotate(360deg);

            }
        }
        .box form
        {
            position: absolute;
            inset:4px;
            background:#222;
            padding:50px 40px;
            border-radius:8px;
            z-index: 2;
            display: flex;
            flex-direction:column;
        }
        .box form h2 
        {
            color:#fff;
            font-weight:500;
            text-align:center;
            letter-spacing:0.1cm;
        }
        
        .box form .inputbox span 
        {
            position: absolute;
            left:0;
            padding: 20px 10px 10px;
            pointer-events:none;
            color:#8f8f8f;
            font-size:1cm;
            letter-spacing:0.05cm;
            transition:0.5s;

        }
       
        .box form .links
        {
            display: flex;
            justify-content: space-between;

        }
        .box form .links a
        {
            margin: 10px 0;
            font-size:15px;
            color:#8f8f8f;
            text-decoration: none;
            text-align:center;
            padding-left:55px;
        }
        .box form .links a:hover,
        .box form .links a:nth-child(2)
        {   
            color:#fff;
        }
     
        .error { color: red; }
          
        </style>
</head>
<body >

<div class="box">
    <span class="borderLine">
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <h2>Login</h2>
        <br>
        <label>Enter Username</label>
        <input type="text" id="username" name="username" required>
        <i></i>
  

        <label>Enter Password</label>
        <input type="password" id="password" name="password" required>
        <i></i>
       <br><br>
   
        
        <input type="submit" name="submit" value="Submit">
        <div class="links">
           <a href="Register.php">If you Don't have Account?<br>Register Here</a>
    </div>
    </form>
    </div>


<?php

if(isset($_POST['submit'])){
    // if (!isset($_SESSION['total_visitors'])) {
    //     $_SESSION['total_visitors'] = 1; // Initialize to 1 for the first visit
    // } else {
        $_SESSION['total_visitors']++; // Increment the visitor count
    // }
	$username=$_POST['username'];
	$password=$_POST['password'];
	
	$query="select * from logindb where username='".$username."' and password='".$password."'";
	$result=mysqli_query($connection,$query);
	$count=mysqli_num_rows($result); 
    if($count==1)
    {
        header("location:main\index.php");

    }  
  
}
?>
</body>
</html>